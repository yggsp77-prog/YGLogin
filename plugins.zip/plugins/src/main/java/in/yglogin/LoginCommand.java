package in.yglogin;

import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public final class LoginCommand implements CommandExecutor {

    private final AuthManager auth;
    private final LoginSession session;
    private final LoginGui gui;

    public LoginCommand(AuthManager auth, LoginSession session, LoginGui gui) {
        this.auth = auth;
        this.session = session;
        this.gui = gui;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player p)) {
            sender.sendMessage("Players only.");
            return true;
        }

        if (!auth.isRegistered(p)) {
            p.sendMessage(ChatColor.RED + "You are not registered. Use /register <password>.");
            gui.open(p);
            return true;
        }

        if (args.length != 1) {
            p.sendMessage(ChatColor.YELLOW + "Usage: /login <password>");
            gui.open(p);
            return true;
        }

        if (!auth.verify(p, args[0])) {
            p.sendMessage(ChatColor.RED + "Wrong password.");
            gui.open(p);
            return true;
        }

        session.setLoggedIn(p.getUniqueId(), true);
        p.closeInventory();
        p.sendMessage(ChatColor.GREEN + "Logged in!");
        return true;
    }
}