package in.yglogin;

import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.Base64;
import java.util.UUID;

public final class AuthManager {

    private final JavaPlugin plugin;
    private final SecureRandom random = new SecureRandom();

    public AuthManager(JavaPlugin plugin) {
        this.plugin = plugin;
    }

    public boolean isRegistered(Player p) {
        return plugin.getConfig().contains(path(p.getUniqueId()) + ".hash");
    }

    public void register(Player p, String password) {
        UUID uuid = p.getUniqueId();
        String salt = newSalt();
        String hash = hash(salt, password);

        FileConfiguration cfg = plugin.getConfig();
        cfg.set(path(uuid) + ".salt", salt);
        cfg.set(path(uuid) + ".hash", hash);
        plugin.saveConfig();
    }

    public boolean verify(Player p, String password) {
        UUID uuid = p.getUniqueId();
        String base = path(uuid);

        String salt = plugin.getConfig().getString(base + ".salt", "");
        String expected = plugin.getConfig().getString(base + ".hash", "");

        if (salt.isEmpty() || expected.isEmpty()) return false;
        return expected.equals(hash(salt, password));
    }

    private String path(UUID uuid) {
        return "users." + uuid;
    }

    private String newSalt() {
        byte[] b = new byte[16];
        random.nextBytes(b);
        return Base64.getEncoder().encodeToString(b);
    }

    private String hash(String saltB64, String password) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            md.update(Base64.getDecoder().decode(saltB64));
            md.update(password.getBytes(StandardCharsets.UTF_8));
            return Base64.getEncoder().encodeToString(md.digest());
        } catch (Exception e) {
            throw new RuntimeException("Hashing failed", e);
        }
    }

    public void setPassword(UUID uuid, String newPassword) {
            String salt = newSalt();
            String hash = hash(salt, newPassword);

            String base = "users." + uuid;
            plugin.getConfig().set(base + ".salt", salt);
            plugin.getConfig().set(base + ".hash", hash);
            plugin.saveConfig();
    }

    public void resetPassword(Player target, String newPassword) {
            setPassword(target.getUniqueId(), newPassword);
}