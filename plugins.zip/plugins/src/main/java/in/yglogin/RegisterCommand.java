package in.yglogin;

import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public final class RegisterCommand implements CommandExecutor {

    private final AuthManager auth;
    private final LoginSession session;
    private final LoginGui gui;

    public RegisterCommand(AuthManager auth, LoginSession session, LoginGui gui) {
        this.auth = auth;
        this.session = session;
        this.gui = gui;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player p)) {
            sender.sendMessage("Players only.");
            return true;
        }

        if (auth.isRegistered(p)) {
            p.sendMessage(ChatColor.RED + "You are already registered. Use /login <password>.");
            gui.open(p);
            return true;
        }

        if (args.length != 1 || args[0].length() < 4) {
            p.sendMessage(ChatColor.YELLOW + "Usage: /register <password> (min 4 chars)");
            gui.open(p);
            return true;
        }

        auth.register(p, args[0]);
        session.setLoggedIn(p.getUniqueId(), true);
        p.closeInventory();
        p.sendMessage(ChatColor.GREEN + "Registered and logged in!");
        return true;
    }
}