package in.yglogin;

import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.player.*;
import org.bukkit.event.block.Action;

public final class PlayerGateListener implements Listener {

    private final YGLoginPlugin plugin;
    private final AuthManager auth;
    private final LoginSession session;
    private final LoginGui gui;

    public PlayerGateListener(YGLoginPlugin plugin, AuthManager auth, LoginSession session, LoginGui gui) {
        this.plugin = plugin;
        this.auth = auth;
        this.session = session;
        this.gui = gui;
    }

    private boolean needsLogin(Player p) {
        if (plugin.isBypass(p)) return false;
        return !session.isLoggedIn(p.getUniqueId());
    }

@EventHandler
public void onJoin(PlayerJoinEvent e) {
    Player p = e.getPlayer();
    if (plugin.isBypass(p)) return;

    session.setLoggedIn(p.getUniqueId(), false);

    p.sendMessage(ChatColor.GREEN + "[YG-Login] " +
            (auth.isRegistered(p)
                    ? "Please login: /login <password>"
                    : "Please register: /register <password>"));

    plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
        if (!p.isOnline() || !needsLogin(p)) return;

        p.teleport(plugin.getLoginSpawn());
        gui.open(p);
    }, 10L);
}

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        session.setLoggedIn(e.getPlayer().getUniqueId(), false);
    }

    // Block movement
    @EventHandler
    public void onMove(PlayerMoveEvent e) {
        Player p = e.getPlayer();
        if (!needsLogin(p)) return;

        if (e.getFrom().getX() != e.getTo().getX()
                || e.getFrom().getY() != e.getTo().getY()
                || e.getFrom().getZ() != e.getTo().getZ()) {
            e.setTo(e.getFrom());
        }
    }

    // Block most commands except /login and /register
    @EventHandler
    public void onCommand(PlayerCommandPreprocessEvent e) {
        Player p = e.getPlayer();
        if (!needsLogin(p)) return;

        String msg = e.getMessage().toLowerCase();
        if (msg.startsWith("/login ") || msg.equals("/login")
                || msg.startsWith("/register ") || msg.equals("/register")) {
            return;
        }

        e.setCancelled(true);
        p.sendMessage(ChatColor.RED + "You must login first.");
        gui.open(p);
    }

    // Block interact/drop/pickup
    @EventHandler
    public void onInteract(PlayerInteractEvent e) {
        if (!needsLogin(e.getPlayer())) return;
        if (e.getAction() == Action.PHYSICAL) return;
        e.setCancelled(true);
    }

    @EventHandler
    public void onDrop(PlayerDropItemEvent e) {
        if (needsLogin(e.getPlayer())) e.setCancelled(true);
    }

    @EventHandler
    public void onPickup(PlayerAttemptPickupItemEvent e) {
        if (needsLogin(e.getPlayer())) e.setCancelled(true);
    }

    // GUI: prevent taking items, reopen if closed while locked
    @EventHandler
    public void onInvClick(InventoryClickEvent e) {
        if (!(e.getWhoClicked() instanceof Player p)) return;
        if (!needsLogin(p)) return;
        if (e.getView().getTitle().contains("YG-Login")) e.setCancelled(true);
    }

    @EventHandler
    public void onInvClose(InventoryCloseEvent e) {
        if (!(e.getPlayer() instanceof Player p)) return;
        if (!needsLogin(p)) return;
        if (e.getView().getTitle().contains("YG-Login")) {
            plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
                if (p.isOnline() && needsLogin(p)) gui.open(p);
            }, 5L);
        }
    }
}