package in.yglogin;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.List;

public final class LoginGui {

    private final JavaPlugin plugin;
    private final AuthManager auth;

    public LoginGui(JavaPlugin plugin, AuthManager auth) {
        this.plugin = plugin;
        this.auth = auth;
    }

    public void open(Player p) {
        boolean registered = auth.isRegistered(p);

        Inventory inv = Bukkit.createInventory(null, 9, ChatColor.DARK_GREEN + "YG-Login");
        inv.setItem(3, button(
                Material.WRITABLE_BOOK,
                registered ? ChatColor.YELLOW + "Login" : ChatColor.AQUA + "Register",
                registered
                        ? List.of(ChatColor.GRAY + "Use: " + ChatColor.WHITE + "/login <password>")
                        : List.of(ChatColor.GRAY + "Use: " + ChatColor.WHITE + "/register <password>")
        ));
        inv.setItem(5, button(
                Material.BARRIER,
                ChatColor.RED + "Close",
                List.of(ChatColor.GRAY + "You must login to play.")
        ));

        p.openInventory(inv);
    }

    private ItemStack button(Material mat, String name, List<String> lore) {
        ItemStack it = new ItemStack(mat);
        ItemMeta meta = it.getItemMeta();
        meta.setDisplayName(name);
        meta.setLore(lore);
        it.setItemMeta(meta);
        return it;
    }
}