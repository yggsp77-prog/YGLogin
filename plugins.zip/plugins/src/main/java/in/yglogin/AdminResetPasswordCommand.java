package in.yglogin;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.*;

import java.util.UUID;

public final class AdminResetPasswordCommand implements CommandExecutor {

    private final AuthManager auth;
    private final LoginSession session;

    public AdminResetPasswordCommand(AuthManager auth, LoginSession session) {
        this.auth = auth;
        this.session = session;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("yglogin.admin.resetpw")) {
            sender.sendMessage(ChatColor.RED + "No permission.");
            return true;
        }

        if (args.length != 2 || args[1].length() < 4) {
            sender.sendMessage(ChatColor.YELLOW + "Usage: /ygresetpw <uuid> <newPassword> (min 4 chars)");
            return true;
        }

        UUID uuid;
        try {
            uuid = UUID.fromString(args[0]);
        } catch (IllegalArgumentException ex) {
            sender.sendMessage(ChatColor.RED + "Invalid UUID format.");
            return true;
        }

        OfflinePlayer target = Bukkit.getOfflinePlayer(uuid); // online or offline [web:62]
        auth.setPassword(uuid, args[1]);

        // If they are online right now, force re-login + message them
        if (target.isOnline() && target.getPlayer() != null) {
            session.setLoggedIn(uuid, false);
            target.getPlayer().sendMessage(ChatColor.RED + "Your password was reset by an admin. Please /login again.");
        }

        sender.sendMessage(ChatColor.GREEN + "Password reset for UUID " + uuid +
                (target.getName() != null ? " (" + target.getName() + ")" : "") + ".");
        return true;
    }
}