package in.yglogin;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

public final class YGLoginPlugin extends JavaPlugin {

    private AuthManager authManager;
    private LoginSession session;
    private LoginGui gui;

    @Override
    public void onEnable() {
        saveDefaultConfig(); // creates config.yml if missing

        this.authManager = new AuthManager(this);
        this.session = new LoginSession();
        this.gui = new LoginGui(this, authManager);

        // Commands
        getCommand("register").setExecutor(new RegisterCommand(authManager, session, gui));
        getCommand("login").setExecutor(new LoginCommand(authManager, session, gui));
        getCommand("changepassword").setExecutor(new ChangePasswordCommand(authManager, session));
        getCommand("ygresetpw").setExecutor(new AdminResetPasswordCommand(authManager, session));

        // Events
        Bukkit.getPluginManager().registerEvents(new PlayerGateListener(this, authManager, session, gui), this);

        getLogger().info("YG-Login enabled.");
    }

    @Override
    public void onDisable() {
        getLogger().info("YG-Login disabled.");
    }

    public boolean isBypass(Player p) {
        return p.hasPermission("yglogin.bypass");
    }
}
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;

public Location getLoginSpawn() {
    String w = getConfig().getString("login-spawn.world", "world");
    World world = Bukkit.getWorld(w);
    if (world == null) world = Bukkit.getWorlds().get(0);

    double x = getConfig().getDouble("login-spawn.x", 0.5);
    double y = getConfig().getDouble("login-spawn.y", 100.0);
    double z = getConfig().getDouble("login-spawn.z", 0.5);
    float yaw = (float) getConfig().getDouble("login-spawn.yaw", 0.0);
    float pitch = (float) getConfig().getDouble("login-spawn.pitch", 0.0);

    return new Location(world, x, y, z, yaw, pitch);
}