package in.yglogin;

import org.bukkit.ChatColor;
import org.bukkit.command.*;
import org.bukkit.entity.Player;

public final class ChangePasswordCommand implements CommandExecutor {

    private final AuthManager auth;
    private final LoginSession session;

    public ChangePasswordCommand(AuthManager auth, LoginSession session) {
        this.auth = auth;
        this.session = session;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player p)) {
            sender.sendMessage("Players only.");
            return true;
        }

        if (!auth.isRegistered(p)) {
            p.sendMessage(ChatColor.RED + "You are not registered.");
            return true;
        }

        if (!session.isLoggedIn(p.getUniqueId())) {
            p.sendMessage(ChatColor.RED + "You must login first.");
            return true;
        }

        if (args.length != 2 || args[1].length() < 4) {
            p.sendMessage(ChatColor.YELLOW + "Usage: /changepassword <old> <new> (min 4 chars)");
            return true;
        }

        String oldPw = args[0];
        String newPw = args[1];

        if (!auth.verify(p, oldPw)) {
            p.sendMessage(ChatColor.RED + "Old password is incorrect.");
            return true;
        }

        auth.setPassword(p.getUniqueId(), newPw);
        p.sendMessage(ChatColor.GREEN + "Password changed.");
        return true;
    }
}