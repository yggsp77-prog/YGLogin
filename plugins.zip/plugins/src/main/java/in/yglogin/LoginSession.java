package in.yglogin;

import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public final class LoginSession {
    private final Set<UUID> loggedIn = ConcurrentHashMap.newKeySet();

    public boolean isLoggedIn(UUID uuid) {
        return loggedIn.contains(uuid);
    }

    public void setLoggedIn(UUID uuid, boolean value) {
        if (value) loggedIn.add(uuid);
        else loggedIn.remove(uuid);
    }
}